These codes are made by Harshit Singh Pakhariya-210101048.

For Q1
For running the Q1 program, first paste these 2 files(210101048_Assign01.awk and INVENTORY.txt) in the same directory.
Then write the following code line/syntax for the execution part:-

awk -f 210101048_Assign01.awk INVENTORY.txt

Now Explaining the code for Assignment 1,
First we write BEGIN Keyword because it means that Awk will execute the action(s) specified in BEGIN once before any input lines are read.So in BEGIN we print the column heads are printed only once because it is not in the loop.Then,the loop starts and we will check the given condition that is if the quantity on hands falls below the reorder point then :-
We will calculate it by adding the reorder point and minimum order subtracting the quantity on hand. otherwise we will leave it to be 0.Then we will just print all columns in each row by ,maintaining the spaces diligently.Then we use the END Keyword to add the footer to the columns to print "END REPORT"

For Q2
For running the Q2 program, first paste these 2 files(210101048_Assign02.sh and EMPLOYEE.txt) in the same directory.
Then write the following the code line/syntax for the execution part:-

bash 210101048_Assign02.sh

Now Explaining the code for Assignment 2,
First we print the column heads of all the columns.Then we start the while loop and also read the input five vaariables at the same time and storing their values in their respective variables.Then the loop starts and we calculate the value of basepay every time we move to new row by the respective formula for bp.Then we initialised ovp and tot variables to 0.Then we checked the condition if the user is Non-Exempt,Then I calculated the Overtime-Pay value in ovp variable if the number of hours are greater than 40 and total Pay in tot.then we stopped the if statement using fi.Then we print all the columns as we are still in the loop.here echo statement is used as print/assignment statement.Then done statement is used to take the input from the respective file.I calculated first the base pay for all  the hours worked then half a time overtime pay for all the extra hours worked i.e for greater than 40.

Thank You Sir.

