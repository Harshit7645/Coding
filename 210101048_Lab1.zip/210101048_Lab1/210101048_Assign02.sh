#!/bin/bash

#This source code is being compiled and executed in LINUX Terminal.The file type is .sh which is a BASH file.
#file="EMPLOYEE.txt"
printf "				  Made By - Harshit Singh Pakhariya - 210101048 \n \n"
#The above line is to certify that the program is being made by me Harshit Singh Pakhariya - 210101048 CSE Branch.
printf "					EMPLOYEE Payroll Register			\n \n"
printf "Employee Number    Department     Pay Rate     Exempt    Hours Worked     Base Pay    Overtime Pay      Total Pay \n \n"
#the above line is to print the column heads of each column and \n is used to pass the control to the new line. 
while read empno dep pra exe hw ; do
#the above line is to start a while loop and read keyword is to scan the values of all the 5 variables and it reads the values from each of the 5 input columns.
#empno variable is storing the employee number of all the employees from the table , dep variable is storing the department number of all the emloyees
#pra is the variable to store the value of the pay rate of the salary of employees , exe is the variable to store the exempt of the employees , hw is used to store the value of the hours worked by each employee
bp=$(echo "($pra*$hw)" | bc)
#bp variable is used to calculate the base pay of each employee including the extra hours worked so base pay is calculated direcly by multiplying the hours worked multiplied by pay rate
#here we are calculating the base pay using the basic caulculator 
ovp=0
tot=0
if [[ $exe == "N" ]];   #if we have the non exempt employee then the overtime pay is calculated using the ovp variable
then
{
    ovp=$(echo "($hw-40.00)*0.5*$pra" | bc)
}
fi
tot=$(echo "$ovp+$bp" | bc)   #here we calculated total pay of each employee
printf "$empno \t \t     $dep \t    $pra \t$exe \t\t$hw \t  $bp \t $ovp \t \t $tot\n \n"  #this line is to print all the column variables values
done <EMPLOYEE.txt
